// seed.js - Insert sample data for testing
const { MongoClient, ObjectId } = require("mongodb");

const uri = "mongodb://localhost:27017"; // change if using Atlas
const dbName = "googleFormsClone";

async function run() {
  const client = new MongoClient(uri);

  try {
    await client.connect();
    const db = client.db(dbName);

    const users = db.collection("users");
    const forms = db.collection("forms");
    const responses = db.collection("responses");

    // Insert user
    const alice = {
      _id: new ObjectId(),
      email: "alice@example.com",
      displayName: "Alice",
      passwordHash: "hashed-password",
      createdAt: new Date(),
      roles: ["creator"]
    };
    await users.insertOne(alice);

    // Insert form
    const formId = new ObjectId();
    const q1Id = new ObjectId();
    const opt1 = new ObjectId();
    const opt2 = new ObjectId();
    const opt3 = new ObjectId();

    const form = {
      _id: formId,
      ownerId: alice._id,
      title: "Team Lunch Poll",
      description: "Pick a day for team lunch",
      type: "poll",
      isPublished: true,
      isAnonymous: true,
      allowMultipleResponses: false,
      settings: { theme: "dark" },
      questions: [
        {
          questionId: q1Id,
          ordinal: 1,
          type: "single_choice",
          prompt: "Which day is best for lunch?",
          required: true,
          options: [
            { optionId: opt1, label: "Monday", ordinal: 1 },
            { optionId: opt2, label: "Wednesday", ordinal: 2 },
            { optionId: opt3, label: "Friday", ordinal: 3 }
          ]
        }
      ],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    await forms.insertOne(form);

    // Insert sample response
    const response = {
      _id: new ObjectId(),
      formId,
      respondentId: null,
      respondentKey: "device-xyz",
      isComplete: true,
      metadata: { ip: "127.0.0.1", userAgent: "Mozilla/5.0" },
      answers: [
        {
          questionId: q1Id,
          optionIds: [opt2] // voted "Wednesday"
        }
      ],
      startedAt: new Date(),
      submittedAt: new Date()
    };
    await responses.insertOne(response);

    console.log("✅ Seed data inserted successfully!");
  } finally {
    await client.close();
  }
}

run().catch(console.dir);
