// models.js - Mongoose models for Google Forms Clone

const mongoose = require("mongoose");

/**
 * User Schema
 */
const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  displayName: { type: String, required: true },
  passwordHash: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  roles: [{ type: String, enum: ["admin", "creator", "respondent"] }]
});

/**
 * Option Sub-Schema
 */
const OptionSchema = new mongoose.Schema({
  optionId: { type: mongoose.Schema.Types.ObjectId, default: () => new mongoose.Types.ObjectId() },
  label: String,
  ordinal: Number
});

/**
 * Question Sub-Schema
 */
const QuestionSchema = new mongoose.Schema({
  questionId: { type: mongoose.Schema.Types.ObjectId, default: () => new mongoose.Types.ObjectId() },
  ordinal: Number,
  type: { type: String, enum: ["short_text", "long_text", "single_choice", "multi_choice", "rating", "date"] },
  prompt: String,
  required: Boolean,
  options: [OptionSchema]
});

/**
 * Form Schema
 */
const FormSchema = new mongoose.Schema({
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  title: String,
  description: String,
  type: { type: String, enum: ["survey", "poll"] },
  isPublished: { type: Boolean, default: false },
  isAnonymous: { type: Boolean, default: true },
  allowMultipleResponses: { type: Boolean, default: false },
  settings: Object,
  questions: [QuestionSchema],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

/**
 * Answer Sub-Schema
 */
const AnswerSchema = new mongoose.Schema({
  questionId: { type: mongoose.Schema.Types.ObjectId },
  answerText: String,
  optionIds: [mongoose.Schema.Types.ObjectId],
  rating: Number,
  dateAnswer: String
});

/**
 * Response Schema
 */
const ResponseSchema = new mongoose.Schema({
  formId: { type: mongoose.Schema.Types.ObjectId, ref: "Form" },
  respondentId: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  respondentKey: { type: String, default: null },
  isComplete: { type: Boolean, default: false },
  metadata: {
    ip: String,
    userAgent: String
  },
  answers: [AnswerSchema],
  startedAt: { type: Date, default: Date.now },
  submittedAt: Date
});

// Models
const User = mongoose.model("User", UserSchema);
const Form = mongoose.model("Form", FormSchema);
const Response = mongoose.model("Response", ResponseSchema);

module.exports = { User, Form, Response };
