# MongoDB Setup for Google Forms Clone

## 1. Start MongoDB locally
```bash
mongod
```

Or connect to your MongoDB Atlas cluster.

## 2. Insert Seed Data
```bash
node db/seed.js
```

This will create:
- **users** → sample user
- **forms** → one poll with a single-choice question
- **responses** → one sample response

## 3. Collections
- **users** → registered users
- **forms** → form definitions (with embedded questions + options)
- **responses** → form submissions
- **(optional)** votes/events → if you need separate voting/audit

Now you can query in MongoDB Compass, shell, or through your backend API.
