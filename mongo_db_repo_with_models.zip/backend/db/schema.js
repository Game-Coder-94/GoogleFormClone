// schema.js - Reference schema for MongoDB collections

/**
 * USERS
 */
const UserSchema = {
  _id: "ObjectId",
  email: "string",
  displayName: "string",
  passwordHash: "string",
  createdAt: "Date",
  roles: ["string"] // ["admin", "creator", "respondent"]
};

/**
 * FORMS
 */
const FormSchema = {
  _id: "ObjectId",
  ownerId: "ObjectId", // reference to users
  title: "string",
  description: "string",
  type: "string", // "survey" | "poll"
  isPublished: "boolean",
  isAnonymous: "boolean",
  allowMultipleResponses: "boolean",
  settings: "object",
  questions: [
    {
      questionId: "ObjectId",
      ordinal: "number",
      type: "string", // "short_text", "multi_choice", etc.
      prompt: "string",
      required: "boolean",
      options: [
        { optionId: "ObjectId", label: "string", ordinal: "number" }
      ]
    }
  ],
  createdAt: "Date",
  updatedAt: "Date"
};

/**
 * RESPONSES
 */
const ResponseSchema = {
  _id: "ObjectId",
  formId: "ObjectId",
  respondentId: "ObjectId | null",
  respondentKey: "string | null",
  isComplete: "boolean",
  metadata: {
    ip: "string",
    userAgent: "string"
  },
  answers: [
    {
      questionId: "ObjectId",
      answerText: "string | null",
      optionIds: ["ObjectId"], // for choice questions
      rating: "number",
      dateAnswer: "string"
    }
  ],
  startedAt: "Date",
  submittedAt: "Date"
};

module.exports = { UserSchema, FormSchema, ResponseSchema };
